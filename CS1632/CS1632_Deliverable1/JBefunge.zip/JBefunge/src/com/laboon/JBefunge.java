package com.laboon;

public class JBefunge {

    public static void main(String[] args) {
	MainWindow m = new MainWindow();
    }
    
}
