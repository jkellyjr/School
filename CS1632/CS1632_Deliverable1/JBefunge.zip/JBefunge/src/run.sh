javac ./com/laboon/*.java
java com.laboon.JBefunge
