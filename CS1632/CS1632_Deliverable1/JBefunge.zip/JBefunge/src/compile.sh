javac ./com/laboon/*.java
