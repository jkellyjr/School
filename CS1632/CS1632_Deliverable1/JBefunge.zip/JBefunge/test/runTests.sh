javac -cp .:../src:./junit-4.12.jar:./mockito-core-1.10.19.jar:./hamcrest-core-1.3.jar:./objenesis-2.4.jar ./com/laboon/*.java
java -cp .:../src:./junit-4.12.jar:./mockito-core-1.10.19.jar:./hamcrest-core-1.3.jar:./objenesis-2.4.jar com.laboon.TestRunner
